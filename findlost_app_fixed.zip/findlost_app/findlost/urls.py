from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

from reporting import views as reporting_views

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', reporting_views.home, name='home'),

    path('login/', auth_views.LoginView.as_view(template_name='accounts/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),

    path('accounts/', include('accounts.urls')),
    path('registry/', include('registry.urls')),
    path('report/', include('reporting.urls')),
    path('matching/', include('matching.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
